let body = document.querySelector("body");
let span = document.querySelector("span");
document.addEventListener("mousemove", (event) => {
    let x = event.offsetX;
    let y = event.offsetY;
    let span = document.createElement("span");
    
    let random = Math.random() * 8;

    span.style.width = 2 + random + "px";
    span.style.height = 2 + random + "px";
    span.style.left = x + "px";
    span.style.top = y + "px";
    body.appendChild(span)

    let red = Math.random() * 255;
    let green = Math.random() * 255;
    let blue = Math.random() * 255;
    // span.style.background = "rgb(" + red + ','+ green + "," + blue +")"

    let rotation = Math.floor(Math.random() * 360);
    span.style.transform = `rotate( `+ rotation + `deg)`
    console.log(span.style.transform);

    setTimeout(() => {
        span.remove();
    }, 1500);
    
    
})